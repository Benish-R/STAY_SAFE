import dash
from dash import dcc, html, Input, Output, State, dash_table
import dash_bootstrap_components as dbc
import pandas as pd
import requests

# OpenWeatherMap API Key (Replace 'YOUR_API_KEY' with an actual API key)
API_KEY = "645767411e2b0a51c0a7eb4c4303fc41"

# Function to fetch weather data
def get_weather(location):
    base_url = "http://api.openweathermap.org/data/2.5/weather"
    params = {"q": location, "appid": API_KEY, "units": "metric"}  # Units in Celsius
    response = requests.get(base_url, params=params)

    if response.status_code == 200:
        data = response.json()
        return {
            "temperature": data["main"]["temp"],
            "description": data["weather"][0]["description"].capitalize(),
            "icon": data["weather"][0]["icon"]
        }
    else:
        return None
# Load Hotel Data
dataframe = pd.read_csv("AI_HOTEL.csv")


# Ensure 'Rating' is numeric
if 'Rating' in dataframe.columns:
    dataframe['Rating'] = pd.to_numeric(dataframe['Rating'], errors='coerce')

# Initialize Dash App
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.LUX], suppress_callback_exceptions=True)
app.title = "Travel & Hotel Finder"

# Global dictionary to store user travel details
travel_data = {}
filtered_hotels = pd.DataFrame()

# Layout for the first page (Travel Form)
def first_page():
    return dbc.Container([
        dbc.Row([dbc.Col(html.H1("✈️ Plan Your Travel", className="text-center text-primary"), width=12)], className="mb-4"),

        dbc.Card([
            dbc.CardBody([
                dbc.Row([
                    dbc.Col(dbc.Input(id='name', placeholder='👤 Enter your name', type='text', className="mb-2"), width=6),
                    dbc.Col(dcc.Dropdown(
                        id='level',
                        options=[{'label': str(i), 'value': str(i)} for i in range(50, 55)],
                        placeholder='🎓 Select your level'
                    ), width=6)
                ]),
                dbc.Row([
                    dbc.Col(dcc.Dropdown(
                        id='location',
                        options=[{'label': loc, 'value': loc} for loc in dataframe['location'].dropna().unique()],
                        placeholder='📍 Select your destination'
                    ), width=6),
                    dbc.Col(dcc.DatePickerSingle(id='date', placeholder='📅 Select a date'), width=6)
                ], className="mb-2"),
                dbc.Row([
                    dbc.Col(dcc.Dropdown(
                        id='meal',
                        options=[{'label': 'Veg', 'value': 'Veg'}, {'label': 'Non-Veg', 'value': 'Non-Veg'}],
                        placeholder='🍽️ Select meal preference'
                    ), width=6),
                    dbc.Col(dbc.Input(id='members', placeholder='👥 No. of people', type='text'), width=6)
                ], className="mb-2"),
                dbc.Row([dbc.Col(dbc.Input(id='purpose', placeholder='🎯 Purpose of travel', type='text'), width=12)], className="mb-4"),
                dbc.Row([dbc.Col(dbc.Button('📩 Submit', id='submit-button', color='primary', className="btn-lg btn-block"), width=12)]),
                dbc.Row([dbc.Col(html.Div(id='output-message', className="mt-3 text-danger fw-bold"), width=12)])
            ])
        ], className="shadow-lg p-3"),

    ], fluid=True)

# Layout for the second page (Travel Summary + Filtered Hotels)
def second_page(travel_info, hotel_data):

    office_locations = {
        "BLR" : "Bangalore",
        "COB" : "Coimbatore",
        "HYD" : "Hyderabad",
        "Unknown" : "Chennai"
    }


    weather_info = get_weather(office_locations.get(travel_info.get("Location", "Unknown")))

    weather_card = dbc.Card(
        dbc.CardBody([
            html.Div([
                html.H4("🌦️ Weather Forecast", className="text-center fw-bold text-primary mb-3"),

                # Location and Date
                dbc.Row([
                    dbc.Col(html.H5(f"📍 {travel_info.get('Location', 'Unknown')}",
                                    className="text-center text-secondary fw-semibold"), width=6),
                    dbc.Col(html.H5(f"📅 {travel_info.get('Date', 'N/A')}",
                                    className="text-center text-muted fw-light"), width=6),
                ], className="mb-3"),

                # Weather Icon & Temperature
                html.Div([
                    html.Img(src=f"http://openweathermap.org/img/wn/{weather_info.get('icon', '01d')}@4x.png",
                             className="d-block mx-auto", style={"width": "80px", "height": "80px"}),
                    html.H2(f"🌡️ {weather_info.get('temperature', '--')}°C",
                            className="text-center text-danger fw-bold"),
                ], className="mb-3"),

                # Weather Description
                html.H5(weather_info.get('description', 'No data available').title(),
                        className="text-center text-success fw-medium"),
            ])
        ]),
        className="p-4 mb-4 rounded-4 border-0",
        style={
            "background": "linear-gradient(to right, rgba(255,255,255,0.8), rgba(240,240,240,0.9))",
            "backdropFilter": "blur(10px)",
            "borderRadius": "15px"
        }
    )


    travel_summary = html.Ul([
        html.Li(f"👤 Name: {travel_info['Name']}", className="mb-1"),
        html.Li(f"🎓 Level: {travel_info['Level']}", className="mb-1"),
        html.Li(f"🎯 Purpose: {travel_info['Purpose']}", className="mb-1"),
        html.Li(f"📍 Destination: {travel_info.get('Location', 'Unknown')}", className="mb-1"),
        html.Li(f"📅 Date: {travel_info['Date']}", className="mb-1"),
        html.Li(f"🍽️ Meal: {travel_info['Meal Preference']}", className="mb-1"),
        html.Li(f"👥 Traveling With: {travel_info['Travelling With']}", className="mb-1")
    ], className="list-group")

    return dbc.Container([
        dbc.Row([dbc.Col(html.H1("✅ Your Travel Summary", className="text-center text-success"), width=12)], className="mb-4"),

        dbc.Card(
            dbc.CardBody([
                html.H4("📄 Travel Details", className="text-primary fw-bold mb-3 text-center"),

                dbc.Row([
                    # Left Column - Traveler Details
                    dbc.Col(
                        dbc.Card(
                            dbc.CardBody([
                                html.H5("👤 Traveler Information", className="text-dark fw-semibold"),
                                html.Div(travel_summary, className="text-muted fs-5"),
                            ]), className="shadow-sm border-0 rounded-3"
                        ), width=6
                    ),

                    # Right Column - Weather Details
                    dbc.Col(weather_card, width=6)
                ], className="g-3")  # Adds spacing between columns
            ]),
            className="shadow-lg p-4 mb-4 rounded-4 border-0",
            style={"background": "linear-gradient(to right, rgba(255,255,255,0.9), rgba(240,240,240,0.8))"}
        ),

        html.Hr(),

        dbc.Row([dbc.Col(html.H2("🏨 Filtered Hotels", className="text-center text-info"), width=12)], className="mb-3"),

        # Improved Filterable Table
        dash_table.DataTable(
            id='filtered-hotel-table',
            columns=[{"name": col, "id": col} for col in hotel_data.columns],
            data=hotel_data.to_dict('records'),
            filter_action="native",
            sort_action="native",
            style_table={'overflowX': 'auto', 'border': '1px solid #ddd', 'borderRadius': '10px', 'boxShadow': '0px 0px 10px rgba(0, 0, 0, 0.1)'},

            # Header Styling
            style_header={
                'backgroundColor': '#007bff',
                'color': 'white',
                'fontWeight': 'bold',
                'border': 'none',
                'padding': '12px'
            },

            # Data Styling
            style_data={
                'borderBottom': '1px solid #ddd',
                'padding': '10px',
                'textAlign': 'left',
            },

            # Styling for Filter Inputs
            style_filter={
                'backgroundColor': '#f8f9fa',
                'border': '1px solid #ccc',
                'borderRadius': '20px',
                'padding': '8px 12px',
                'margin': '5px',
                # 'boxShadow': '0px 2px 5px rgba(0, 0, 0, 0.1)',
                'fontSize': '14px',
                'color': '#333',
                'boxShadow': 'none'
    },

            # Cells Styling
            style_cell={
                'padding': '10px',
                'textAlign': 'left',
            },

            page_size=10
        ),

        html.Div(className="mt-3")
    ], fluid=True)

# Callback: Store travel details, filter hotels, and navigate to next page
@app.callback(
    [Output('url', 'pathname'), Output('output-message', 'children')],
    [Input('submit-button', 'n_clicks')],
    [State('name', 'value'),
     State('level', 'value'),
     State('purpose', 'value'),
     State('location', 'value'),
     State('date', 'date'),
     State('meal', 'value'),
     State('members', 'value')]
)
def process_travel_details(n_clicks, name, level, purpose, location, date, meal, members):
    if n_clicks is None:
        return dash.no_update, ""

    if not all([name, level, purpose, location, date, meal, members]):
        return dash.no_update, "⚠️ Please fill out all fields before submitting."

    # Store travel details
    travel_info = {
        "Name": name,
        "Level": level,
        "Purpose": purpose,
        "Location": location,
        "Date": date,
        "Meal Preference": meal,
        "Travelling With": members
    }

    global travel_data, filtered_hotels
    travel_data.update(travel_info)

    # Filter hotels based on travel location
    filtered_hotels = dataframe[
        (dataframe['location'] == location) &
        (dataframe['level'].astype(str) == str(level))
        ]

    return '/summary', "✅ Travel details submitted! Redirecting..."

# Callback: Display correct page based on URL
@app.callback(
    Output('page-content', 'children'),
    [Input('url', 'pathname')],
    # [State('name', 'value'), State('location', 'value')],
    prevent_initial_call=True
)
def display_page(pathname):
    if pathname == '/summary':
        return second_page(travel_data, filtered_hotels)
    return first_page()


# Initialize app layout with URL routing
app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    html.Div(id='page-content')
])

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
